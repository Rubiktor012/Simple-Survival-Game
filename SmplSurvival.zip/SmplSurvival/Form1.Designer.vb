﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.LblEnergy = New System.Windows.Forms.Label()
        Me.PgrEnergy = New System.Windows.Forms.ProgressBar()
        Me.X1Y1 = New System.Windows.Forms.Panel()
        Me.X2Y1 = New System.Windows.Forms.Panel()
        Me.X3Y1 = New System.Windows.Forms.Panel()
        Me.X4Y1 = New System.Windows.Forms.Panel()
        Me.X5Y1 = New System.Windows.Forms.Panel()
        Me.X6Y1 = New System.Windows.Forms.Panel()
        Me.X7Y1 = New System.Windows.Forms.Panel()
        Me.X8Y1 = New System.Windows.Forms.Panel()
        Me.X8Y2 = New System.Windows.Forms.Panel()
        Me.X7Y2 = New System.Windows.Forms.Panel()
        Me.X6Y2 = New System.Windows.Forms.Panel()
        Me.X5Y2 = New System.Windows.Forms.Panel()
        Me.X4Y2 = New System.Windows.Forms.Panel()
        Me.X3Y2 = New System.Windows.Forms.Panel()
        Me.X2Y2 = New System.Windows.Forms.Panel()
        Me.X1Y2 = New System.Windows.Forms.Panel()
        Me.X8Y3 = New System.Windows.Forms.Panel()
        Me.X7Y3 = New System.Windows.Forms.Panel()
        Me.X6Y3 = New System.Windows.Forms.Panel()
        Me.X5Y3 = New System.Windows.Forms.Panel()
        Me.X4Y3 = New System.Windows.Forms.Panel()
        Me.X3Y3 = New System.Windows.Forms.Panel()
        Me.X2Y3 = New System.Windows.Forms.Panel()
        Me.X1Y3 = New System.Windows.Forms.Panel()
        Me.X8Y4 = New System.Windows.Forms.Panel()
        Me.X7Y4 = New System.Windows.Forms.Panel()
        Me.X6Y4 = New System.Windows.Forms.Panel()
        Me.X5Y4 = New System.Windows.Forms.Panel()
        Me.X4Y4 = New System.Windows.Forms.Panel()
        Me.X3Y4 = New System.Windows.Forms.Panel()
        Me.X2Y4 = New System.Windows.Forms.Panel()
        Me.X1Y4 = New System.Windows.Forms.Panel()
        Me.X8Y5 = New System.Windows.Forms.Panel()
        Me.X7Y5 = New System.Windows.Forms.Panel()
        Me.X6Y5 = New System.Windows.Forms.Panel()
        Me.X5Y5 = New System.Windows.Forms.Panel()
        Me.X4Y5 = New System.Windows.Forms.Panel()
        Me.X3Y5 = New System.Windows.Forms.Panel()
        Me.X2Y5 = New System.Windows.Forms.Panel()
        Me.X1Y5 = New System.Windows.Forms.Panel()
        Me.X8Y6 = New System.Windows.Forms.Panel()
        Me.X7Y6 = New System.Windows.Forms.Panel()
        Me.X6Y6 = New System.Windows.Forms.Panel()
        Me.X5Y6 = New System.Windows.Forms.Panel()
        Me.X4Y6 = New System.Windows.Forms.Panel()
        Me.X3Y6 = New System.Windows.Forms.Panel()
        Me.X2Y6 = New System.Windows.Forms.Panel()
        Me.X1Y6 = New System.Windows.Forms.Panel()
        Me.X8Y7 = New System.Windows.Forms.Panel()
        Me.X7Y7 = New System.Windows.Forms.Panel()
        Me.X6Y7 = New System.Windows.Forms.Panel()
        Me.X5Y7 = New System.Windows.Forms.Panel()
        Me.X4Y7 = New System.Windows.Forms.Panel()
        Me.X3Y7 = New System.Windows.Forms.Panel()
        Me.X2Y7 = New System.Windows.Forms.Panel()
        Me.X1Y7 = New System.Windows.Forms.Panel()
        Me.X8Y8 = New System.Windows.Forms.Panel()
        Me.X7Y8 = New System.Windows.Forms.Panel()
        Me.X6Y8 = New System.Windows.Forms.Panel()
        Me.X5Y8 = New System.Windows.Forms.Panel()
        Me.X4Y8 = New System.Windows.Forms.Panel()
        Me.X3Y8 = New System.Windows.Forms.Panel()
        Me.X2Y8 = New System.Windows.Forms.Panel()
        Me.X1Y8 = New System.Windows.Forms.Panel()
        Me.BtnBuildMine = New System.Windows.Forms.Button()
        Me.BtnBuildCamp = New System.Windows.Forms.Button()
        Me.BtnBuildWell = New System.Windows.Forms.Button()
        Me.LblBuild = New System.Windows.Forms.Label()
        Me.LblActions = New System.Windows.Forms.Label()
        Me.BtnDrink = New System.Windows.Forms.Button()
        Me.BtnBuildFarm = New System.Windows.Forms.Button()
        Me.BtnEat = New System.Windows.Forms.Button()
        Me.LblMinePrice = New System.Windows.Forms.Label()
        Me.LblCampPrice = New System.Windows.Forms.Label()
        Me.LblWellPrice = New System.Windows.Forms.Label()
        Me.LblFarmPrice = New System.Windows.Forms.Label()
        Me.PgrThirst = New System.Windows.Forms.ProgressBar()
        Me.LblThirst = New System.Windows.Forms.Label()
        Me.LblHunger = New System.Windows.Forms.Label()
        Me.PgrHunger = New System.Windows.Forms.ProgressBar()
        Me.BtnSell = New System.Windows.Forms.Button()
        Me.TmrHunger = New System.Windows.Forms.Timer(Me.components)
        Me.TmrThirst = New System.Windows.Forms.Timer(Me.components)
        Me.TmrEnergy = New System.Windows.Forms.Timer(Me.components)
        Me.TmrResources = New System.Windows.Forms.Timer(Me.components)
        Me.LblFood = New System.Windows.Forms.Label()
        Me.LblWater = New System.Windows.Forms.Label()
        Me.LblGold = New System.Windows.Forms.Label()
        Me.LblDie = New System.Windows.Forms.Label()
        Me.BtnRetry = New System.Windows.Forms.Button()
        Me.TmrGold = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'LblEnergy
        '
        Me.LblEnergy.AutoSize = True
        Me.LblEnergy.Location = New System.Drawing.Point(14, 17)
        Me.LblEnergy.Name = "LblEnergy"
        Me.LblEnergy.Size = New System.Drawing.Size(43, 13)
        Me.LblEnergy.TabIndex = 0
        Me.LblEnergy.Text = "Energy:"
        '
        'PgrEnergy
        '
        Me.PgrEnergy.Location = New System.Drawing.Point(63, 13)
        Me.PgrEnergy.Maximum = 10
        Me.PgrEnergy.Name = "PgrEnergy"
        Me.PgrEnergy.Size = New System.Drawing.Size(725, 23)
        Me.PgrEnergy.TabIndex = 1
        Me.PgrEnergy.Value = 10
        '
        'X1Y1
        '
        Me.X1Y1.BackColor = System.Drawing.Color.Silver
        Me.X1Y1.Location = New System.Drawing.Point(63, 42)
        Me.X1Y1.Name = "X1Y1"
        Me.X1Y1.Size = New System.Drawing.Size(40, 40)
        Me.X1Y1.TabIndex = 2
        '
        'X2Y1
        '
        Me.X2Y1.BackColor = System.Drawing.Color.Silver
        Me.X2Y1.Location = New System.Drawing.Point(109, 42)
        Me.X2Y1.Name = "X2Y1"
        Me.X2Y1.Size = New System.Drawing.Size(40, 40)
        Me.X2Y1.TabIndex = 3
        '
        'X3Y1
        '
        Me.X3Y1.BackColor = System.Drawing.Color.Silver
        Me.X3Y1.Location = New System.Drawing.Point(155, 42)
        Me.X3Y1.Name = "X3Y1"
        Me.X3Y1.Size = New System.Drawing.Size(40, 40)
        Me.X3Y1.TabIndex = 4
        '
        'X4Y1
        '
        Me.X4Y1.BackColor = System.Drawing.Color.Silver
        Me.X4Y1.Location = New System.Drawing.Point(201, 42)
        Me.X4Y1.Name = "X4Y1"
        Me.X4Y1.Size = New System.Drawing.Size(40, 40)
        Me.X4Y1.TabIndex = 5
        '
        'X5Y1
        '
        Me.X5Y1.BackColor = System.Drawing.Color.Silver
        Me.X5Y1.Location = New System.Drawing.Point(247, 42)
        Me.X5Y1.Name = "X5Y1"
        Me.X5Y1.Size = New System.Drawing.Size(40, 40)
        Me.X5Y1.TabIndex = 6
        '
        'X6Y1
        '
        Me.X6Y1.BackColor = System.Drawing.Color.Silver
        Me.X6Y1.Location = New System.Drawing.Point(293, 42)
        Me.X6Y1.Name = "X6Y1"
        Me.X6Y1.Size = New System.Drawing.Size(40, 40)
        Me.X6Y1.TabIndex = 7
        '
        'X7Y1
        '
        Me.X7Y1.BackColor = System.Drawing.Color.Silver
        Me.X7Y1.Location = New System.Drawing.Point(339, 42)
        Me.X7Y1.Name = "X7Y1"
        Me.X7Y1.Size = New System.Drawing.Size(40, 40)
        Me.X7Y1.TabIndex = 8
        '
        'X8Y1
        '
        Me.X8Y1.BackColor = System.Drawing.Color.Silver
        Me.X8Y1.Location = New System.Drawing.Point(385, 42)
        Me.X8Y1.Name = "X8Y1"
        Me.X8Y1.Size = New System.Drawing.Size(40, 40)
        Me.X8Y1.TabIndex = 9
        '
        'X8Y2
        '
        Me.X8Y2.BackColor = System.Drawing.Color.Silver
        Me.X8Y2.Location = New System.Drawing.Point(385, 88)
        Me.X8Y2.Name = "X8Y2"
        Me.X8Y2.Size = New System.Drawing.Size(40, 40)
        Me.X8Y2.TabIndex = 17
        '
        'X7Y2
        '
        Me.X7Y2.BackColor = System.Drawing.Color.Silver
        Me.X7Y2.Location = New System.Drawing.Point(339, 88)
        Me.X7Y2.Name = "X7Y2"
        Me.X7Y2.Size = New System.Drawing.Size(40, 40)
        Me.X7Y2.TabIndex = 16
        '
        'X6Y2
        '
        Me.X6Y2.BackColor = System.Drawing.Color.Silver
        Me.X6Y2.Location = New System.Drawing.Point(293, 88)
        Me.X6Y2.Name = "X6Y2"
        Me.X6Y2.Size = New System.Drawing.Size(40, 40)
        Me.X6Y2.TabIndex = 15
        '
        'X5Y2
        '
        Me.X5Y2.BackColor = System.Drawing.Color.Silver
        Me.X5Y2.Location = New System.Drawing.Point(247, 88)
        Me.X5Y2.Name = "X5Y2"
        Me.X5Y2.Size = New System.Drawing.Size(40, 40)
        Me.X5Y2.TabIndex = 14
        '
        'X4Y2
        '
        Me.X4Y2.BackColor = System.Drawing.Color.Silver
        Me.X4Y2.Location = New System.Drawing.Point(201, 88)
        Me.X4Y2.Name = "X4Y2"
        Me.X4Y2.Size = New System.Drawing.Size(40, 40)
        Me.X4Y2.TabIndex = 13
        '
        'X3Y2
        '
        Me.X3Y2.BackColor = System.Drawing.Color.Silver
        Me.X3Y2.Location = New System.Drawing.Point(155, 88)
        Me.X3Y2.Name = "X3Y2"
        Me.X3Y2.Size = New System.Drawing.Size(40, 40)
        Me.X3Y2.TabIndex = 12
        '
        'X2Y2
        '
        Me.X2Y2.BackColor = System.Drawing.Color.Silver
        Me.X2Y2.Location = New System.Drawing.Point(109, 88)
        Me.X2Y2.Name = "X2Y2"
        Me.X2Y2.Size = New System.Drawing.Size(40, 40)
        Me.X2Y2.TabIndex = 11
        '
        'X1Y2
        '
        Me.X1Y2.BackColor = System.Drawing.Color.Silver
        Me.X1Y2.Location = New System.Drawing.Point(63, 88)
        Me.X1Y2.Name = "X1Y2"
        Me.X1Y2.Size = New System.Drawing.Size(40, 40)
        Me.X1Y2.TabIndex = 10
        '
        'X8Y3
        '
        Me.X8Y3.BackColor = System.Drawing.Color.Silver
        Me.X8Y3.Location = New System.Drawing.Point(385, 134)
        Me.X8Y3.Name = "X8Y3"
        Me.X8Y3.Size = New System.Drawing.Size(40, 40)
        Me.X8Y3.TabIndex = 25
        '
        'X7Y3
        '
        Me.X7Y3.BackColor = System.Drawing.Color.Silver
        Me.X7Y3.Location = New System.Drawing.Point(339, 134)
        Me.X7Y3.Name = "X7Y3"
        Me.X7Y3.Size = New System.Drawing.Size(40, 40)
        Me.X7Y3.TabIndex = 24
        '
        'X6Y3
        '
        Me.X6Y3.BackColor = System.Drawing.Color.Silver
        Me.X6Y3.Location = New System.Drawing.Point(293, 134)
        Me.X6Y3.Name = "X6Y3"
        Me.X6Y3.Size = New System.Drawing.Size(40, 40)
        Me.X6Y3.TabIndex = 23
        '
        'X5Y3
        '
        Me.X5Y3.BackColor = System.Drawing.Color.Silver
        Me.X5Y3.Location = New System.Drawing.Point(247, 134)
        Me.X5Y3.Name = "X5Y3"
        Me.X5Y3.Size = New System.Drawing.Size(40, 40)
        Me.X5Y3.TabIndex = 22
        '
        'X4Y3
        '
        Me.X4Y3.BackColor = System.Drawing.Color.Silver
        Me.X4Y3.Location = New System.Drawing.Point(201, 134)
        Me.X4Y3.Name = "X4Y3"
        Me.X4Y3.Size = New System.Drawing.Size(40, 40)
        Me.X4Y3.TabIndex = 21
        '
        'X3Y3
        '
        Me.X3Y3.BackColor = System.Drawing.Color.Silver
        Me.X3Y3.Location = New System.Drawing.Point(155, 134)
        Me.X3Y3.Name = "X3Y3"
        Me.X3Y3.Size = New System.Drawing.Size(40, 40)
        Me.X3Y3.TabIndex = 20
        '
        'X2Y3
        '
        Me.X2Y3.BackColor = System.Drawing.Color.Silver
        Me.X2Y3.Location = New System.Drawing.Point(109, 134)
        Me.X2Y3.Name = "X2Y3"
        Me.X2Y3.Size = New System.Drawing.Size(40, 40)
        Me.X2Y3.TabIndex = 19
        '
        'X1Y3
        '
        Me.X1Y3.BackColor = System.Drawing.Color.Silver
        Me.X1Y3.Location = New System.Drawing.Point(63, 134)
        Me.X1Y3.Name = "X1Y3"
        Me.X1Y3.Size = New System.Drawing.Size(40, 40)
        Me.X1Y3.TabIndex = 18
        '
        'X8Y4
        '
        Me.X8Y4.BackColor = System.Drawing.Color.Silver
        Me.X8Y4.Location = New System.Drawing.Point(385, 180)
        Me.X8Y4.Name = "X8Y4"
        Me.X8Y4.Size = New System.Drawing.Size(40, 40)
        Me.X8Y4.TabIndex = 33
        '
        'X7Y4
        '
        Me.X7Y4.BackColor = System.Drawing.Color.Silver
        Me.X7Y4.Location = New System.Drawing.Point(339, 180)
        Me.X7Y4.Name = "X7Y4"
        Me.X7Y4.Size = New System.Drawing.Size(40, 40)
        Me.X7Y4.TabIndex = 32
        '
        'X6Y4
        '
        Me.X6Y4.BackColor = System.Drawing.Color.Silver
        Me.X6Y4.Location = New System.Drawing.Point(293, 180)
        Me.X6Y4.Name = "X6Y4"
        Me.X6Y4.Size = New System.Drawing.Size(40, 40)
        Me.X6Y4.TabIndex = 31
        '
        'X5Y4
        '
        Me.X5Y4.BackColor = System.Drawing.Color.Silver
        Me.X5Y4.Location = New System.Drawing.Point(247, 180)
        Me.X5Y4.Name = "X5Y4"
        Me.X5Y4.Size = New System.Drawing.Size(40, 40)
        Me.X5Y4.TabIndex = 30
        '
        'X4Y4
        '
        Me.X4Y4.BackColor = System.Drawing.Color.Silver
        Me.X4Y4.Location = New System.Drawing.Point(201, 180)
        Me.X4Y4.Name = "X4Y4"
        Me.X4Y4.Size = New System.Drawing.Size(40, 40)
        Me.X4Y4.TabIndex = 29
        '
        'X3Y4
        '
        Me.X3Y4.BackColor = System.Drawing.Color.Silver
        Me.X3Y4.Location = New System.Drawing.Point(155, 180)
        Me.X3Y4.Name = "X3Y4"
        Me.X3Y4.Size = New System.Drawing.Size(40, 40)
        Me.X3Y4.TabIndex = 28
        '
        'X2Y4
        '
        Me.X2Y4.BackColor = System.Drawing.Color.Silver
        Me.X2Y4.Location = New System.Drawing.Point(109, 180)
        Me.X2Y4.Name = "X2Y4"
        Me.X2Y4.Size = New System.Drawing.Size(40, 40)
        Me.X2Y4.TabIndex = 27
        '
        'X1Y4
        '
        Me.X1Y4.BackColor = System.Drawing.Color.Silver
        Me.X1Y4.Location = New System.Drawing.Point(63, 180)
        Me.X1Y4.Name = "X1Y4"
        Me.X1Y4.Size = New System.Drawing.Size(40, 40)
        Me.X1Y4.TabIndex = 26
        '
        'X8Y5
        '
        Me.X8Y5.BackColor = System.Drawing.Color.Silver
        Me.X8Y5.Location = New System.Drawing.Point(385, 226)
        Me.X8Y5.Name = "X8Y5"
        Me.X8Y5.Size = New System.Drawing.Size(40, 40)
        Me.X8Y5.TabIndex = 41
        '
        'X7Y5
        '
        Me.X7Y5.BackColor = System.Drawing.Color.Silver
        Me.X7Y5.Location = New System.Drawing.Point(339, 226)
        Me.X7Y5.Name = "X7Y5"
        Me.X7Y5.Size = New System.Drawing.Size(40, 40)
        Me.X7Y5.TabIndex = 40
        '
        'X6Y5
        '
        Me.X6Y5.BackColor = System.Drawing.Color.Silver
        Me.X6Y5.Location = New System.Drawing.Point(293, 226)
        Me.X6Y5.Name = "X6Y5"
        Me.X6Y5.Size = New System.Drawing.Size(40, 40)
        Me.X6Y5.TabIndex = 39
        '
        'X5Y5
        '
        Me.X5Y5.BackColor = System.Drawing.Color.Silver
        Me.X5Y5.Location = New System.Drawing.Point(247, 226)
        Me.X5Y5.Name = "X5Y5"
        Me.X5Y5.Size = New System.Drawing.Size(40, 40)
        Me.X5Y5.TabIndex = 38
        '
        'X4Y5
        '
        Me.X4Y5.BackColor = System.Drawing.Color.Silver
        Me.X4Y5.Location = New System.Drawing.Point(201, 226)
        Me.X4Y5.Name = "X4Y5"
        Me.X4Y5.Size = New System.Drawing.Size(40, 40)
        Me.X4Y5.TabIndex = 37
        '
        'X3Y5
        '
        Me.X3Y5.BackColor = System.Drawing.Color.Silver
        Me.X3Y5.Location = New System.Drawing.Point(155, 226)
        Me.X3Y5.Name = "X3Y5"
        Me.X3Y5.Size = New System.Drawing.Size(40, 40)
        Me.X3Y5.TabIndex = 36
        '
        'X2Y5
        '
        Me.X2Y5.BackColor = System.Drawing.Color.Silver
        Me.X2Y5.Location = New System.Drawing.Point(109, 226)
        Me.X2Y5.Name = "X2Y5"
        Me.X2Y5.Size = New System.Drawing.Size(40, 40)
        Me.X2Y5.TabIndex = 35
        '
        'X1Y5
        '
        Me.X1Y5.BackColor = System.Drawing.Color.Silver
        Me.X1Y5.Location = New System.Drawing.Point(63, 226)
        Me.X1Y5.Name = "X1Y5"
        Me.X1Y5.Size = New System.Drawing.Size(40, 40)
        Me.X1Y5.TabIndex = 34
        '
        'X8Y6
        '
        Me.X8Y6.BackColor = System.Drawing.Color.Silver
        Me.X8Y6.Location = New System.Drawing.Point(385, 272)
        Me.X8Y6.Name = "X8Y6"
        Me.X8Y6.Size = New System.Drawing.Size(40, 40)
        Me.X8Y6.TabIndex = 49
        '
        'X7Y6
        '
        Me.X7Y6.BackColor = System.Drawing.Color.Silver
        Me.X7Y6.Location = New System.Drawing.Point(339, 272)
        Me.X7Y6.Name = "X7Y6"
        Me.X7Y6.Size = New System.Drawing.Size(40, 40)
        Me.X7Y6.TabIndex = 48
        '
        'X6Y6
        '
        Me.X6Y6.BackColor = System.Drawing.Color.Silver
        Me.X6Y6.Location = New System.Drawing.Point(293, 272)
        Me.X6Y6.Name = "X6Y6"
        Me.X6Y6.Size = New System.Drawing.Size(40, 40)
        Me.X6Y6.TabIndex = 47
        '
        'X5Y6
        '
        Me.X5Y6.BackColor = System.Drawing.Color.Silver
        Me.X5Y6.Location = New System.Drawing.Point(247, 272)
        Me.X5Y6.Name = "X5Y6"
        Me.X5Y6.Size = New System.Drawing.Size(40, 40)
        Me.X5Y6.TabIndex = 46
        '
        'X4Y6
        '
        Me.X4Y6.BackColor = System.Drawing.Color.Silver
        Me.X4Y6.Location = New System.Drawing.Point(201, 272)
        Me.X4Y6.Name = "X4Y6"
        Me.X4Y6.Size = New System.Drawing.Size(40, 40)
        Me.X4Y6.TabIndex = 45
        '
        'X3Y6
        '
        Me.X3Y6.BackColor = System.Drawing.Color.Silver
        Me.X3Y6.Location = New System.Drawing.Point(155, 272)
        Me.X3Y6.Name = "X3Y6"
        Me.X3Y6.Size = New System.Drawing.Size(40, 40)
        Me.X3Y6.TabIndex = 44
        '
        'X2Y6
        '
        Me.X2Y6.BackColor = System.Drawing.Color.Silver
        Me.X2Y6.Location = New System.Drawing.Point(109, 272)
        Me.X2Y6.Name = "X2Y6"
        Me.X2Y6.Size = New System.Drawing.Size(40, 40)
        Me.X2Y6.TabIndex = 43
        '
        'X1Y6
        '
        Me.X1Y6.BackColor = System.Drawing.Color.Silver
        Me.X1Y6.Location = New System.Drawing.Point(63, 272)
        Me.X1Y6.Name = "X1Y6"
        Me.X1Y6.Size = New System.Drawing.Size(40, 40)
        Me.X1Y6.TabIndex = 42
        '
        'X8Y7
        '
        Me.X8Y7.BackColor = System.Drawing.Color.Silver
        Me.X8Y7.Location = New System.Drawing.Point(385, 318)
        Me.X8Y7.Name = "X8Y7"
        Me.X8Y7.Size = New System.Drawing.Size(40, 40)
        Me.X8Y7.TabIndex = 57
        '
        'X7Y7
        '
        Me.X7Y7.BackColor = System.Drawing.Color.Silver
        Me.X7Y7.Location = New System.Drawing.Point(339, 318)
        Me.X7Y7.Name = "X7Y7"
        Me.X7Y7.Size = New System.Drawing.Size(40, 40)
        Me.X7Y7.TabIndex = 56
        '
        'X6Y7
        '
        Me.X6Y7.BackColor = System.Drawing.Color.Silver
        Me.X6Y7.Location = New System.Drawing.Point(293, 318)
        Me.X6Y7.Name = "X6Y7"
        Me.X6Y7.Size = New System.Drawing.Size(40, 40)
        Me.X6Y7.TabIndex = 55
        '
        'X5Y7
        '
        Me.X5Y7.BackColor = System.Drawing.Color.Silver
        Me.X5Y7.Location = New System.Drawing.Point(247, 318)
        Me.X5Y7.Name = "X5Y7"
        Me.X5Y7.Size = New System.Drawing.Size(40, 40)
        Me.X5Y7.TabIndex = 54
        '
        'X4Y7
        '
        Me.X4Y7.BackColor = System.Drawing.Color.Silver
        Me.X4Y7.Location = New System.Drawing.Point(201, 318)
        Me.X4Y7.Name = "X4Y7"
        Me.X4Y7.Size = New System.Drawing.Size(40, 40)
        Me.X4Y7.TabIndex = 53
        '
        'X3Y7
        '
        Me.X3Y7.BackColor = System.Drawing.Color.Silver
        Me.X3Y7.Location = New System.Drawing.Point(155, 318)
        Me.X3Y7.Name = "X3Y7"
        Me.X3Y7.Size = New System.Drawing.Size(40, 40)
        Me.X3Y7.TabIndex = 52
        '
        'X2Y7
        '
        Me.X2Y7.BackColor = System.Drawing.Color.Silver
        Me.X2Y7.Location = New System.Drawing.Point(109, 318)
        Me.X2Y7.Name = "X2Y7"
        Me.X2Y7.Size = New System.Drawing.Size(40, 40)
        Me.X2Y7.TabIndex = 51
        '
        'X1Y7
        '
        Me.X1Y7.BackColor = System.Drawing.Color.Silver
        Me.X1Y7.Location = New System.Drawing.Point(63, 318)
        Me.X1Y7.Name = "X1Y7"
        Me.X1Y7.Size = New System.Drawing.Size(40, 40)
        Me.X1Y7.TabIndex = 50
        '
        'X8Y8
        '
        Me.X8Y8.BackColor = System.Drawing.Color.Silver
        Me.X8Y8.Location = New System.Drawing.Point(385, 364)
        Me.X8Y8.Name = "X8Y8"
        Me.X8Y8.Size = New System.Drawing.Size(40, 40)
        Me.X8Y8.TabIndex = 65
        '
        'X7Y8
        '
        Me.X7Y8.BackColor = System.Drawing.Color.Silver
        Me.X7Y8.Location = New System.Drawing.Point(339, 364)
        Me.X7Y8.Name = "X7Y8"
        Me.X7Y8.Size = New System.Drawing.Size(40, 40)
        Me.X7Y8.TabIndex = 64
        '
        'X6Y8
        '
        Me.X6Y8.BackColor = System.Drawing.Color.Silver
        Me.X6Y8.Location = New System.Drawing.Point(293, 364)
        Me.X6Y8.Name = "X6Y8"
        Me.X6Y8.Size = New System.Drawing.Size(40, 40)
        Me.X6Y8.TabIndex = 63
        '
        'X5Y8
        '
        Me.X5Y8.BackColor = System.Drawing.Color.Silver
        Me.X5Y8.Location = New System.Drawing.Point(247, 364)
        Me.X5Y8.Name = "X5Y8"
        Me.X5Y8.Size = New System.Drawing.Size(40, 40)
        Me.X5Y8.TabIndex = 62
        '
        'X4Y8
        '
        Me.X4Y8.BackColor = System.Drawing.Color.Silver
        Me.X4Y8.Location = New System.Drawing.Point(201, 364)
        Me.X4Y8.Name = "X4Y8"
        Me.X4Y8.Size = New System.Drawing.Size(40, 40)
        Me.X4Y8.TabIndex = 61
        '
        'X3Y8
        '
        Me.X3Y8.BackColor = System.Drawing.Color.Silver
        Me.X3Y8.Location = New System.Drawing.Point(155, 364)
        Me.X3Y8.Name = "X3Y8"
        Me.X3Y8.Size = New System.Drawing.Size(40, 40)
        Me.X3Y8.TabIndex = 60
        '
        'X2Y8
        '
        Me.X2Y8.BackColor = System.Drawing.Color.Silver
        Me.X2Y8.Location = New System.Drawing.Point(109, 364)
        Me.X2Y8.Name = "X2Y8"
        Me.X2Y8.Size = New System.Drawing.Size(40, 40)
        Me.X2Y8.TabIndex = 59
        '
        'X1Y8
        '
        Me.X1Y8.BackColor = System.Drawing.Color.Silver
        Me.X1Y8.Location = New System.Drawing.Point(63, 364)
        Me.X1Y8.Name = "X1Y8"
        Me.X1Y8.Size = New System.Drawing.Size(40, 40)
        Me.X1Y8.TabIndex = 58
        '
        'BtnBuildMine
        '
        Me.BtnBuildMine.BackColor = System.Drawing.Color.Yellow
        Me.BtnBuildMine.Location = New System.Drawing.Point(431, 58)
        Me.BtnBuildMine.Name = "BtnBuildMine"
        Me.BtnBuildMine.Size = New System.Drawing.Size(75, 23)
        Me.BtnBuildMine.TabIndex = 66
        Me.BtnBuildMine.Text = "Gold Mine"
        Me.BtnBuildMine.UseVisualStyleBackColor = False
        '
        'BtnBuildCamp
        '
        Me.BtnBuildCamp.BackColor = System.Drawing.Color.Red
        Me.BtnBuildCamp.Location = New System.Drawing.Point(431, 87)
        Me.BtnBuildCamp.Name = "BtnBuildCamp"
        Me.BtnBuildCamp.Size = New System.Drawing.Size(75, 23)
        Me.BtnBuildCamp.TabIndex = 67
        Me.BtnBuildCamp.Text = "Camp"
        Me.BtnBuildCamp.UseVisualStyleBackColor = False
        '
        'BtnBuildWell
        '
        Me.BtnBuildWell.BackColor = System.Drawing.Color.Cyan
        Me.BtnBuildWell.Location = New System.Drawing.Point(431, 116)
        Me.BtnBuildWell.Name = "BtnBuildWell"
        Me.BtnBuildWell.Size = New System.Drawing.Size(75, 23)
        Me.BtnBuildWell.TabIndex = 68
        Me.BtnBuildWell.Text = "Well"
        Me.BtnBuildWell.UseVisualStyleBackColor = False
        '
        'LblBuild
        '
        Me.LblBuild.AutoSize = True
        Me.LblBuild.Location = New System.Drawing.Point(432, 42)
        Me.LblBuild.Name = "LblBuild"
        Me.LblBuild.Size = New System.Drawing.Size(33, 13)
        Me.LblBuild.TabIndex = 70
        Me.LblBuild.Text = "Build:"
        '
        'LblActions
        '
        Me.LblActions.AutoSize = True
        Me.LblActions.Location = New System.Drawing.Point(568, 42)
        Me.LblActions.Name = "LblActions"
        Me.LblActions.Size = New System.Drawing.Size(45, 13)
        Me.LblActions.TabIndex = 72
        Me.LblActions.Text = "Actions:"
        '
        'BtnDrink
        '
        Me.BtnDrink.BackColor = System.Drawing.Color.Cyan
        Me.BtnDrink.Location = New System.Drawing.Point(571, 58)
        Me.BtnDrink.Name = "BtnDrink"
        Me.BtnDrink.Size = New System.Drawing.Size(75, 23)
        Me.BtnDrink.TabIndex = 73
        Me.BtnDrink.Text = "Drink"
        Me.BtnDrink.UseVisualStyleBackColor = False
        '
        'BtnBuildFarm
        '
        Me.BtnBuildFarm.BackColor = System.Drawing.Color.Brown
        Me.BtnBuildFarm.Location = New System.Drawing.Point(431, 145)
        Me.BtnBuildFarm.Name = "BtnBuildFarm"
        Me.BtnBuildFarm.Size = New System.Drawing.Size(75, 23)
        Me.BtnBuildFarm.TabIndex = 74
        Me.BtnBuildFarm.Text = "Farm"
        Me.BtnBuildFarm.UseVisualStyleBackColor = False
        '
        'BtnEat
        '
        Me.BtnEat.BackColor = System.Drawing.Color.Brown
        Me.BtnEat.Location = New System.Drawing.Point(571, 87)
        Me.BtnEat.Name = "BtnEat"
        Me.BtnEat.Size = New System.Drawing.Size(75, 23)
        Me.BtnEat.TabIndex = 75
        Me.BtnEat.Text = "Eat"
        Me.BtnEat.UseVisualStyleBackColor = False
        '
        'LblMinePrice
        '
        Me.LblMinePrice.AutoSize = True
        Me.LblMinePrice.Location = New System.Drawing.Point(512, 63)
        Me.LblMinePrice.Name = "LblMinePrice"
        Me.LblMinePrice.Size = New System.Drawing.Size(19, 13)
        Me.LblMinePrice.TabIndex = 77
        Me.LblMinePrice.Text = "50"
        '
        'LblCampPrice
        '
        Me.LblCampPrice.AutoSize = True
        Me.LblCampPrice.Location = New System.Drawing.Point(512, 92)
        Me.LblCampPrice.Name = "LblCampPrice"
        Me.LblCampPrice.Size = New System.Drawing.Size(19, 13)
        Me.LblCampPrice.TabIndex = 78
        Me.LblCampPrice.Text = "20"
        '
        'LblWellPrice
        '
        Me.LblWellPrice.AutoSize = True
        Me.LblWellPrice.Location = New System.Drawing.Point(512, 121)
        Me.LblWellPrice.Name = "LblWellPrice"
        Me.LblWellPrice.Size = New System.Drawing.Size(19, 13)
        Me.LblWellPrice.TabIndex = 79
        Me.LblWellPrice.Text = "30"
        '
        'LblFarmPrice
        '
        Me.LblFarmPrice.AutoSize = True
        Me.LblFarmPrice.Location = New System.Drawing.Point(512, 150)
        Me.LblFarmPrice.Name = "LblFarmPrice"
        Me.LblFarmPrice.Size = New System.Drawing.Size(19, 13)
        Me.LblFarmPrice.TabIndex = 80
        Me.LblFarmPrice.Text = "40"
        '
        'PgrThirst
        '
        Me.PgrThirst.Location = New System.Drawing.Point(478, 226)
        Me.PgrThirst.Maximum = 20
        Me.PgrThirst.Name = "PgrThirst"
        Me.PgrThirst.Size = New System.Drawing.Size(310, 23)
        Me.PgrThirst.TabIndex = 81
        Me.PgrThirst.Value = 20
        '
        'LblThirst
        '
        Me.LblThirst.AutoSize = True
        Me.LblThirst.Location = New System.Drawing.Point(433, 231)
        Me.LblThirst.Name = "LblThirst"
        Me.LblThirst.Size = New System.Drawing.Size(36, 13)
        Me.LblThirst.TabIndex = 83
        Me.LblThirst.Text = "Thirst:"
        '
        'LblHunger
        '
        Me.LblHunger.AutoSize = True
        Me.LblHunger.Location = New System.Drawing.Point(433, 260)
        Me.LblHunger.Name = "LblHunger"
        Me.LblHunger.Size = New System.Drawing.Size(45, 13)
        Me.LblHunger.TabIndex = 85
        Me.LblHunger.Text = "Hunger:"
        '
        'PgrHunger
        '
        Me.PgrHunger.Location = New System.Drawing.Point(478, 255)
        Me.PgrHunger.Maximum = 20
        Me.PgrHunger.Name = "PgrHunger"
        Me.PgrHunger.Size = New System.Drawing.Size(310, 23)
        Me.PgrHunger.TabIndex = 84
        Me.PgrHunger.Value = 20
        '
        'BtnSell
        '
        Me.BtnSell.Location = New System.Drawing.Point(432, 175)
        Me.BtnSell.Name = "BtnSell"
        Me.BtnSell.Size = New System.Drawing.Size(75, 23)
        Me.BtnSell.TabIndex = 86
        Me.BtnSell.Text = "Sell"
        Me.BtnSell.UseVisualStyleBackColor = True
        '
        'TmrHunger
        '
        Me.TmrHunger.Enabled = True
        Me.TmrHunger.Interval = 750
        '
        'TmrThirst
        '
        Me.TmrThirst.Enabled = True
        Me.TmrThirst.Interval = 750
        '
        'TmrEnergy
        '
        Me.TmrEnergy.Enabled = True
        Me.TmrEnergy.Interval = 10000
        '
        'TmrResources
        '
        Me.TmrResources.Enabled = True
        Me.TmrResources.Interval = 5000
        '
        'LblFood
        '
        Me.LblFood.AutoSize = True
        Me.LblFood.Location = New System.Drawing.Point(652, 84)
        Me.LblFood.Name = "LblFood"
        Me.LblFood.Size = New System.Drawing.Size(74, 13)
        Me.LblFood.TabIndex = 91
        Me.LblFood.Text = "Your Food: 10"
        '
        'LblWater
        '
        Me.LblWater.AutoSize = True
        Me.LblWater.Location = New System.Drawing.Point(652, 71)
        Me.LblWater.Name = "LblWater"
        Me.LblWater.Size = New System.Drawing.Size(79, 13)
        Me.LblWater.TabIndex = 90
        Me.LblWater.Text = "Your Water: 10"
        '
        'LblGold
        '
        Me.LblGold.AutoSize = True
        Me.LblGold.Location = New System.Drawing.Point(652, 58)
        Me.LblGold.Name = "LblGold"
        Me.LblGold.Size = New System.Drawing.Size(78, 13)
        Me.LblGold.TabIndex = 89
        Me.LblGold.Text = "Your Gold: 420"
        '
        'LblDie
        '
        Me.LblDie.AutoSize = True
        Me.LblDie.BackColor = System.Drawing.SystemColors.Control
        Me.LblDie.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDie.ForeColor = System.Drawing.Color.Red
        Me.LblDie.Location = New System.Drawing.Point(270, 189)
        Me.LblDie.Name = "LblDie"
        Me.LblDie.Size = New System.Drawing.Size(288, 55)
        Me.LblDie.TabIndex = 92
        Me.LblDie.Text = "You Died!!1!"
        Me.LblDie.Visible = False
        '
        'BtnRetry
        '
        Me.BtnRetry.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRetry.Location = New System.Drawing.Point(346, 247)
        Me.BtnRetry.Name = "BtnRetry"
        Me.BtnRetry.Size = New System.Drawing.Size(126, 57)
        Me.BtnRetry.TabIndex = 93
        Me.BtnRetry.Text = "Retry"
        Me.BtnRetry.UseVisualStyleBackColor = True
        Me.BtnRetry.Visible = False
        '
        'TmrGold
        '
        Me.TmrGold.Enabled = True
        Me.TmrGold.Interval = 500
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 414)
        Me.Controls.Add(Me.BtnRetry)
        Me.Controls.Add(Me.LblDie)
        Me.Controls.Add(Me.LblFood)
        Me.Controls.Add(Me.LblWater)
        Me.Controls.Add(Me.LblGold)
        Me.Controls.Add(Me.BtnSell)
        Me.Controls.Add(Me.LblHunger)
        Me.Controls.Add(Me.PgrHunger)
        Me.Controls.Add(Me.LblThirst)
        Me.Controls.Add(Me.PgrThirst)
        Me.Controls.Add(Me.LblFarmPrice)
        Me.Controls.Add(Me.LblWellPrice)
        Me.Controls.Add(Me.LblCampPrice)
        Me.Controls.Add(Me.LblMinePrice)
        Me.Controls.Add(Me.BtnEat)
        Me.Controls.Add(Me.BtnBuildFarm)
        Me.Controls.Add(Me.BtnDrink)
        Me.Controls.Add(Me.LblActions)
        Me.Controls.Add(Me.LblBuild)
        Me.Controls.Add(Me.BtnBuildWell)
        Me.Controls.Add(Me.BtnBuildCamp)
        Me.Controls.Add(Me.BtnBuildMine)
        Me.Controls.Add(Me.X8Y8)
        Me.Controls.Add(Me.X7Y8)
        Me.Controls.Add(Me.X6Y8)
        Me.Controls.Add(Me.X5Y8)
        Me.Controls.Add(Me.X4Y8)
        Me.Controls.Add(Me.X3Y8)
        Me.Controls.Add(Me.X2Y8)
        Me.Controls.Add(Me.X1Y8)
        Me.Controls.Add(Me.X8Y7)
        Me.Controls.Add(Me.X7Y7)
        Me.Controls.Add(Me.X6Y7)
        Me.Controls.Add(Me.X5Y7)
        Me.Controls.Add(Me.X4Y7)
        Me.Controls.Add(Me.X3Y7)
        Me.Controls.Add(Me.X2Y7)
        Me.Controls.Add(Me.X1Y7)
        Me.Controls.Add(Me.X8Y6)
        Me.Controls.Add(Me.X7Y6)
        Me.Controls.Add(Me.X6Y6)
        Me.Controls.Add(Me.X5Y6)
        Me.Controls.Add(Me.X4Y6)
        Me.Controls.Add(Me.X3Y6)
        Me.Controls.Add(Me.X2Y6)
        Me.Controls.Add(Me.X1Y6)
        Me.Controls.Add(Me.X8Y5)
        Me.Controls.Add(Me.X7Y5)
        Me.Controls.Add(Me.X6Y5)
        Me.Controls.Add(Me.X5Y5)
        Me.Controls.Add(Me.X4Y5)
        Me.Controls.Add(Me.X3Y5)
        Me.Controls.Add(Me.X2Y5)
        Me.Controls.Add(Me.X1Y5)
        Me.Controls.Add(Me.X8Y4)
        Me.Controls.Add(Me.X7Y4)
        Me.Controls.Add(Me.X6Y4)
        Me.Controls.Add(Me.X5Y4)
        Me.Controls.Add(Me.X4Y4)
        Me.Controls.Add(Me.X3Y4)
        Me.Controls.Add(Me.X2Y4)
        Me.Controls.Add(Me.X1Y4)
        Me.Controls.Add(Me.X8Y3)
        Me.Controls.Add(Me.X7Y3)
        Me.Controls.Add(Me.X6Y3)
        Me.Controls.Add(Me.X5Y3)
        Me.Controls.Add(Me.X4Y3)
        Me.Controls.Add(Me.X3Y3)
        Me.Controls.Add(Me.X2Y3)
        Me.Controls.Add(Me.X1Y3)
        Me.Controls.Add(Me.X8Y2)
        Me.Controls.Add(Me.X7Y2)
        Me.Controls.Add(Me.X6Y2)
        Me.Controls.Add(Me.X5Y2)
        Me.Controls.Add(Me.X4Y2)
        Me.Controls.Add(Me.X3Y2)
        Me.Controls.Add(Me.X2Y2)
        Me.Controls.Add(Me.X1Y2)
        Me.Controls.Add(Me.X8Y1)
        Me.Controls.Add(Me.X7Y1)
        Me.Controls.Add(Me.X6Y1)
        Me.Controls.Add(Me.X5Y1)
        Me.Controls.Add(Me.X4Y1)
        Me.Controls.Add(Me.X3Y1)
        Me.Controls.Add(Me.X2Y1)
        Me.Controls.Add(Me.X1Y1)
        Me.Controls.Add(Me.PgrEnergy)
        Me.Controls.Add(Me.LblEnergy)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Form1"
        Me.Text = "Simple Survival Game"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LblEnergy As Label
    Friend WithEvents PgrEnergy As ProgressBar
    Friend WithEvents X1Y1 As Panel
    Friend WithEvents X2Y1 As Panel
    Friend WithEvents X3Y1 As Panel
    Friend WithEvents X4Y1 As Panel
    Friend WithEvents X5Y1 As Panel
    Friend WithEvents X6Y1 As Panel
    Friend WithEvents X7Y1 As Panel
    Friend WithEvents X8Y1 As Panel
    Friend WithEvents X8Y2 As Panel
    Friend WithEvents X7Y2 As Panel
    Friend WithEvents X6Y2 As Panel
    Friend WithEvents X5Y2 As Panel
    Friend WithEvents X4Y2 As Panel
    Friend WithEvents X3Y2 As Panel
    Friend WithEvents X2Y2 As Panel
    Friend WithEvents X1Y2 As Panel
    Friend WithEvents X8Y3 As Panel
    Friend WithEvents X7Y3 As Panel
    Friend WithEvents X6Y3 As Panel
    Friend WithEvents X5Y3 As Panel
    Friend WithEvents X4Y3 As Panel
    Friend WithEvents X3Y3 As Panel
    Friend WithEvents X2Y3 As Panel
    Friend WithEvents X1Y3 As Panel
    Friend WithEvents X8Y4 As Panel
    Friend WithEvents X7Y4 As Panel
    Friend WithEvents X6Y4 As Panel
    Friend WithEvents X5Y4 As Panel
    Friend WithEvents X4Y4 As Panel
    Friend WithEvents X3Y4 As Panel
    Friend WithEvents X2Y4 As Panel
    Friend WithEvents X1Y4 As Panel
    Friend WithEvents X8Y5 As Panel
    Friend WithEvents X7Y5 As Panel
    Friend WithEvents X6Y5 As Panel
    Friend WithEvents X5Y5 As Panel
    Friend WithEvents X4Y5 As Panel
    Friend WithEvents X3Y5 As Panel
    Friend WithEvents X2Y5 As Panel
    Friend WithEvents X1Y5 As Panel
    Friend WithEvents X8Y6 As Panel
    Friend WithEvents X7Y6 As Panel
    Friend WithEvents X6Y6 As Panel
    Friend WithEvents X5Y6 As Panel
    Friend WithEvents X4Y6 As Panel
    Friend WithEvents X3Y6 As Panel
    Friend WithEvents X2Y6 As Panel
    Friend WithEvents X1Y6 As Panel
    Friend WithEvents X8Y7 As Panel
    Friend WithEvents X7Y7 As Panel
    Friend WithEvents X6Y7 As Panel
    Friend WithEvents X5Y7 As Panel
    Friend WithEvents X4Y7 As Panel
    Friend WithEvents X3Y7 As Panel
    Friend WithEvents X2Y7 As Panel
    Friend WithEvents X1Y7 As Panel
    Friend WithEvents X8Y8 As Panel
    Friend WithEvents X7Y8 As Panel
    Friend WithEvents X6Y8 As Panel
    Friend WithEvents X5Y8 As Panel
    Friend WithEvents X4Y8 As Panel
    Friend WithEvents X3Y8 As Panel
    Friend WithEvents X2Y8 As Panel
    Friend WithEvents X1Y8 As Panel
    Friend WithEvents BtnBuildMine As Button
    Friend WithEvents BtnBuildCamp As Button
    Friend WithEvents BtnBuildWell As Button
    Friend WithEvents LblBuild As Label
    Friend WithEvents LblActions As Label
    Friend WithEvents BtnDrink As Button
    Friend WithEvents BtnBuildFarm As Button
    Friend WithEvents BtnEat As Button
    Friend WithEvents LblMinePrice As Label
    Friend WithEvents LblCampPrice As Label
    Friend WithEvents LblWellPrice As Label
    Friend WithEvents LblFarmPrice As Label
    Friend WithEvents PgrThirst As ProgressBar
    Friend WithEvents LblThirst As Label
    Friend WithEvents LblHunger As Label
    Friend WithEvents PgrHunger As ProgressBar
    Friend WithEvents BtnSell As Button
    Friend WithEvents TmrHunger As Timer
    Friend WithEvents TmrThirst As Timer
    Friend WithEvents TmrEnergy As Timer
    Friend WithEvents TmrResources As Timer
    Friend WithEvents LblFood As Label
    Friend WithEvents LblWater As Label
    Friend WithEvents LblGold As Label
    Friend WithEvents LblDie As Label
    Friend WithEvents BtnRetry As Button
    Friend WithEvents TmrGold As Timer
End Class
