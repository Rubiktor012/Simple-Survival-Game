﻿Public Class Form1
    Dim Gold As Integer = 420
    Dim Hunger As Integer = 20
    Dim Thirst As Integer = 20
    Dim Energy As Integer = 10
    Dim EnergyMax As Integer = 10
    Dim CurrentBuilding As String = ""
    Dim Mines As Integer = 0
    Dim Camps As Integer = 0
    Dim Wells As Integer = 0
    Dim Farms As Integer = 0
    Dim Water As Integer = 10
    Dim Food As Integer = 10

    Private Sub BtnBuildMine_Click(sender As Object, e As EventArgs) Handles BtnBuildMine.Click
        CurrentBuilding = "GoldMine"
    End Sub

    Private Sub BtnBuildCamp_Click(sender As Object, e As EventArgs) Handles BtnBuildCamp.Click
        CurrentBuilding = "Camp"
    End Sub

    Private Sub BtnBuildWell_Click(sender As Object, e As EventArgs) Handles BtnBuildWell.Click
        CurrentBuilding = "Well"
    End Sub

    Private Sub BtnBuildFarm_Click(sender As Object, e As EventArgs) Handles BtnBuildFarm.Click
        CurrentBuilding = "Farm"
    End Sub

    Private Sub BtnSell_Click(sender As Object, e As EventArgs) Handles BtnSell.Click
        CurrentBuilding = "Sell"
    End Sub

    Private Sub X1Y1_Click(sender As Object, e As EventArgs) Handles X1Y1.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X1Y1.BackColor = Color.Silver Then
                X1Y1.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X1Y1.BackColor = Color.Silver Then
                X1Y1.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X1Y1.BackColor = Color.Silver Then
                X1Y1.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X1Y1.BackColor = Color.Silver Then
                X1Y1.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X1Y1.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X1Y1.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X1Y1.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X1Y1.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X1Y1.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X2Y1_Click(sender As Object, e As EventArgs) Handles X2Y1.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X2Y1.BackColor = Color.Silver Then
                X2Y1.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X2Y1.BackColor = Color.Silver Then
                X2Y1.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X2Y1.BackColor = Color.Silver Then
                X2Y1.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X2Y1.BackColor = Color.Silver Then
                X2Y1.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X2Y1.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X2Y1.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X2Y1.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X2Y1.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X2Y1.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X3Y1_Click(sender As Object, e As EventArgs) Handles X3Y1.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X3Y1.BackColor = Color.Silver Then
                X3Y1.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X3Y1.BackColor = Color.Silver Then
                X3Y1.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X3Y1.BackColor = Color.Silver Then
                X3Y1.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X3Y1.BackColor = Color.Silver Then
                X3Y1.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X3Y1.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X3Y1.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X3Y1.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X3Y1.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X3Y1.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X4Y1_Click(sender As Object, e As EventArgs) Handles X4Y1.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X4Y1.BackColor = Color.Silver Then
                X4Y1.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X4Y1.BackColor = Color.Silver Then
                X4Y1.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X4Y1.BackColor = Color.Silver Then
                X4Y1.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X4Y1.BackColor = Color.Silver Then
                X4Y1.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X4Y1.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X4Y1.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X4Y1.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X4Y1.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X4Y1.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X5Y1_Click(sender As Object, e As EventArgs) Handles X5Y1.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X5Y1.BackColor = Color.Silver Then
                X5Y1.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X5Y1.BackColor = Color.Silver Then
                X5Y1.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X5Y1.BackColor = Color.Silver Then
                X5Y1.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X5Y1.BackColor = Color.Silver Then
                X5Y1.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X5Y1.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X5Y1.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X5Y1.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X5Y1.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X5Y1.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X6Y1_Click(sender As Object, e As EventArgs) Handles X6Y1.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X6Y1.BackColor = Color.Silver Then
                X6Y1.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X6Y1.BackColor = Color.Silver Then
                X6Y1.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X6Y1.BackColor = Color.Silver Then
                X6Y1.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X6Y1.BackColor = Color.Silver Then
                X6Y1.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X6Y1.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X6Y1.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X6Y1.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X6Y1.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X6Y1.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X7Y1_Click(sender As Object, e As EventArgs) Handles X7Y1.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X7Y1.BackColor = Color.Silver Then
                X7Y1.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X7Y1.BackColor = Color.Silver Then
                X7Y1.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X7Y1.BackColor = Color.Silver Then
                X7Y1.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X7Y1.BackColor = Color.Silver Then
                X7Y1.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X7Y1.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X7Y1.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X7Y1.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X7Y1.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X7Y1.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X8Y1_Click(sender As Object, e As EventArgs) Handles X8Y1.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X8Y1.BackColor = Color.Silver Then
                X8Y1.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X8Y1.BackColor = Color.Silver Then
                X8Y1.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X8Y1.BackColor = Color.Silver Then
                X8Y1.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X8Y1.BackColor = Color.Silver Then
                X8Y1.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X8Y1.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X8Y1.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X8Y1.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X8Y1.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X8Y1.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X1Y2_Click(sender As Object, e As EventArgs) Handles X1Y2.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X1Y2.BackColor = Color.Silver Then
                X1Y2.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X1Y2.BackColor = Color.Silver Then
                X1Y2.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X1Y2.BackColor = Color.Silver Then
                X1Y2.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X1Y2.BackColor = Color.Silver Then
                X1Y2.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X1Y2.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X1Y2.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X1Y2.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X1Y2.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X1Y2.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X2Y2_Click(sender As Object, e As EventArgs) Handles X2Y2.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X2Y2.BackColor = Color.Silver Then
                X2Y2.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X2Y2.BackColor = Color.Silver Then
                X2Y2.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X2Y2.BackColor = Color.Silver Then
                X2Y2.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X2Y2.BackColor = Color.Silver Then
                X2Y2.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X2Y2.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X2Y2.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X2Y2.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X2Y2.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X2Y2.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X3Y2_Click(sender As Object, e As EventArgs) Handles X3Y2.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X3Y2.BackColor = Color.Silver Then
                X3Y2.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X3Y2.BackColor = Color.Silver Then
                X3Y2.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X3Y2.BackColor = Color.Silver Then
                X3Y2.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X3Y2.BackColor = Color.Silver Then
                X3Y2.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X3Y2.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X3Y2.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X3Y2.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X3Y2.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X3Y2.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X4Y2_Click(sender As Object, e As EventArgs) Handles X4Y2.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X4Y2.BackColor = Color.Silver Then
                X4Y2.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X4Y2.BackColor = Color.Silver Then
                X4Y2.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X4Y2.BackColor = Color.Silver Then
                X4Y2.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X4Y2.BackColor = Color.Silver Then
                X4Y2.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X4Y2.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X4Y2.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X4Y2.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X4Y2.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X4Y2.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X5Y2_Click(sender As Object, e As EventArgs) Handles X5Y2.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X5Y2.BackColor = Color.Silver Then
                X5Y2.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X5Y2.BackColor = Color.Silver Then
                X5Y2.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X5Y2.BackColor = Color.Silver Then
                X5Y2.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X5Y2.BackColor = Color.Silver Then
                X5Y2.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X5Y2.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X5Y2.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X5Y2.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X5Y2.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X5Y2.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X6Y2_Click(sender As Object, e As EventArgs) Handles X6Y2.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X6Y2.BackColor = Color.Silver Then
                X6Y2.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X6Y2.BackColor = Color.Silver Then
                X6Y2.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X6Y2.BackColor = Color.Silver Then
                X6Y2.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X6Y2.BackColor = Color.Silver Then
                X6Y2.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X6Y2.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X6Y2.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X6Y2.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X6Y2.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X6Y2.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X7Y2_Click(sender As Object, e As EventArgs) Handles X7Y2.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X7Y2.BackColor = Color.Silver Then
                X7Y2.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X7Y2.BackColor = Color.Silver Then
                X7Y2.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X7Y2.BackColor = Color.Silver Then
                X7Y2.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X7Y2.BackColor = Color.Silver Then
                X7Y2.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X7Y2.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X7Y2.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X7Y2.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X7Y2.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X7Y2.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X8Y2_Click(sender As Object, e As EventArgs) Handles X8Y2.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X8Y2.BackColor = Color.Silver Then
                X8Y2.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X8Y2.BackColor = Color.Silver Then
                X8Y2.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X8Y2.BackColor = Color.Silver Then
                X8Y2.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X8Y2.BackColor = Color.Silver Then
                X8Y2.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X8Y2.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X8Y2.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X8Y2.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X8Y2.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X8Y2.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X1Y3_Click(sender As Object, e As EventArgs) Handles X1Y3.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X1Y3.BackColor = Color.Silver Then
                X1Y3.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X1Y3.BackColor = Color.Silver Then
                X1Y3.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X1Y3.BackColor = Color.Silver Then
                X1Y3.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X1Y3.BackColor = Color.Silver Then
                X1Y3.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X1Y3.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X1Y3.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X1Y3.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X1Y3.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X1Y3.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X2Y3_Click(sender As Object, e As EventArgs) Handles X2Y3.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X2Y3.BackColor = Color.Silver Then
                X2Y3.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X2Y3.BackColor = Color.Silver Then
                X2Y3.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X2Y3.BackColor = Color.Silver Then
                X2Y3.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X2Y3.BackColor = Color.Silver Then
                X2Y3.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X2Y3.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X2Y3.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X2Y3.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X2Y3.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X2Y3.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X3Y3_Click(sender As Object, e As EventArgs) Handles X3Y3.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X3Y3.BackColor = Color.Silver Then
                X3Y3.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X3Y3.BackColor = Color.Silver Then
                X3Y3.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X3Y3.BackColor = Color.Silver Then
                X3Y3.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X3Y3.BackColor = Color.Silver Then
                X3Y3.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X3Y3.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X3Y3.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X3Y3.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X3Y3.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X3Y3.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X4Y3_Click(sender As Object, e As EventArgs) Handles X4Y3.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X4Y3.BackColor = Color.Silver Then
                X4Y3.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X4Y3.BackColor = Color.Silver Then
                X4Y3.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X4Y3.BackColor = Color.Silver Then
                X4Y3.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X4Y3.BackColor = Color.Silver Then
                X4Y3.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X4Y3.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X4Y3.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X4Y3.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X4Y3.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X4Y3.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X5Y3_Click(sender As Object, e As EventArgs) Handles X5Y3.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X5Y3.BackColor = Color.Silver Then
                X5Y3.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X5Y3.BackColor = Color.Silver Then
                X5Y3.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X5Y3.BackColor = Color.Silver Then
                X5Y3.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X5Y3.BackColor = Color.Silver Then
                X5Y3.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X5Y3.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X5Y3.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X5Y3.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X5Y3.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X5Y3.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X6Y3_Click(sender As Object, e As EventArgs) Handles X6Y3.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X6Y3.BackColor = Color.Silver Then
                X6Y3.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X6Y3.BackColor = Color.Silver Then
                X6Y3.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X6Y3.BackColor = Color.Silver Then
                X6Y3.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X6Y3.BackColor = Color.Silver Then
                X6Y3.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X6Y3.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X6Y3.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X6Y3.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X6Y3.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X6Y3.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X7Y3_Click(sender As Object, e As EventArgs) Handles X7Y3.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X7Y3.BackColor = Color.Silver Then
                X7Y3.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X7Y3.BackColor = Color.Silver Then
                X7Y3.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X7Y3.BackColor = Color.Silver Then
                X7Y3.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X7Y3.BackColor = Color.Silver Then
                X7Y3.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X7Y3.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X7Y3.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X7Y3.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X7Y3.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X7Y3.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X8Y3_Click(sender As Object, e As EventArgs) Handles X8Y3.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X8Y3.BackColor = Color.Silver Then
                X8Y3.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X8Y3.BackColor = Color.Silver Then
                X8Y3.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X8Y3.BackColor = Color.Silver Then
                X8Y3.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X8Y3.BackColor = Color.Silver Then
                X8Y3.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X8Y3.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X8Y3.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X8Y3.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X8Y3.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X8Y3.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X1Y4_Click(sender As Object, e As EventArgs) Handles X1Y4.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X1Y4.BackColor = Color.Silver Then
                X1Y4.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X1Y4.BackColor = Color.Silver Then
                X1Y4.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X1Y4.BackColor = Color.Silver Then
                X1Y4.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X1Y4.BackColor = Color.Silver Then
                X1Y4.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X1Y4.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X1Y4.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X1Y4.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X1Y4.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X1Y4.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X2Y4_Click(sender As Object, e As EventArgs) Handles X2Y4.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X2Y4.BackColor = Color.Silver Then
                X2Y4.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X2Y4.BackColor = Color.Silver Then
                X2Y4.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X2Y4.BackColor = Color.Silver Then
                X2Y4.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X2Y4.BackColor = Color.Silver Then
                X2Y4.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X2Y4.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X2Y4.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X2Y4.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X2Y4.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X2Y4.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X3Y4_Click(sender As Object, e As EventArgs) Handles X3Y4.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X3Y4.BackColor = Color.Silver Then
                X3Y4.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X3Y4.BackColor = Color.Silver Then
                X3Y4.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X3Y4.BackColor = Color.Silver Then
                X3Y4.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X3Y4.BackColor = Color.Silver Then
                X3Y4.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X3Y4.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X3Y4.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X3Y4.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X3Y4.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X3Y4.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X4Y4_Click(sender As Object, e As EventArgs) Handles X4Y4.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X4Y4.BackColor = Color.Silver Then
                X4Y4.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X4Y4.BackColor = Color.Silver Then
                X4Y4.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X4Y4.BackColor = Color.Silver Then
                X4Y4.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X4Y4.BackColor = Color.Silver Then
                X4Y4.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X4Y4.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X4Y4.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X4Y4.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X4Y4.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X4Y4.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X5Y4_Click(sender As Object, e As EventArgs) Handles X5Y4.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X5Y4.BackColor = Color.Silver Then
                X5Y4.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X5Y4.BackColor = Color.Silver Then
                X5Y4.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X5Y4.BackColor = Color.Silver Then
                X5Y4.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X5Y4.BackColor = Color.Silver Then
                X5Y4.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X5Y4.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X5Y4.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X5Y4.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X5Y4.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X5Y4.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X6Y4_Click(sender As Object, e As EventArgs) Handles X6Y4.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X6Y4.BackColor = Color.Silver Then
                X6Y4.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X6Y4.BackColor = Color.Silver Then
                X6Y4.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X6Y4.BackColor = Color.Silver Then
                X6Y4.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X6Y4.BackColor = Color.Silver Then
                X6Y4.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X6Y4.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X6Y4.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X6Y4.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X6Y4.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X6Y4.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X7Y4_Click(sender As Object, e As EventArgs) Handles X7Y4.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X7Y4.BackColor = Color.Silver Then
                X7Y4.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X7Y4.BackColor = Color.Silver Then
                X7Y4.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X7Y4.BackColor = Color.Silver Then
                X7Y4.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X7Y4.BackColor = Color.Silver Then
                X7Y4.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X7Y4.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X7Y4.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X7Y4.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X7Y4.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X7Y4.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X8Y4_Click(sender As Object, e As EventArgs) Handles X8Y4.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X8Y4.BackColor = Color.Silver Then
                X8Y4.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X8Y4.BackColor = Color.Silver Then
                X8Y4.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X8Y4.BackColor = Color.Silver Then
                X8Y4.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X8Y4.BackColor = Color.Silver Then
                X8Y4.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X8Y4.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X8Y4.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X8Y4.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X8Y4.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X8Y4.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X1Y5_Click(sender As Object, e As EventArgs) Handles X1Y5.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X1Y5.BackColor = Color.Silver Then
                X1Y5.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X1Y5.BackColor = Color.Silver Then
                X1Y5.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X1Y5.BackColor = Color.Silver Then
                X1Y5.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X1Y5.BackColor = Color.Silver Then
                X1Y5.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X1Y5.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X1Y5.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X1Y5.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X1Y5.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X1Y5.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X2Y5_Click(sender As Object, e As EventArgs) Handles X2Y5.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X2Y5.BackColor = Color.Silver Then
                X2Y5.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X2Y5.BackColor = Color.Silver Then
                X2Y5.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X2Y5.BackColor = Color.Silver Then
                X2Y5.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X2Y5.BackColor = Color.Silver Then
                X2Y5.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X2Y5.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X2Y5.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X2Y5.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X2Y5.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X2Y5.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X3Y5_Click(sender As Object, e As EventArgs) Handles X3Y5.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X3Y5.BackColor = Color.Silver Then
                X3Y5.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X3Y5.BackColor = Color.Silver Then
                X3Y5.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X3Y5.BackColor = Color.Silver Then
                X3Y5.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X3Y5.BackColor = Color.Silver Then
                X3Y5.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X3Y5.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X3Y5.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X3Y5.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X3Y5.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X3Y5.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X4Y5_Click(sender As Object, e As EventArgs) Handles X4Y5.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X4Y5.BackColor = Color.Silver Then
                X4Y5.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X4Y5.BackColor = Color.Silver Then
                X4Y5.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X4Y5.BackColor = Color.Silver Then
                X4Y5.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X4Y5.BackColor = Color.Silver Then
                X4Y5.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X4Y5.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X4Y5.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X4Y5.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X4Y5.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X4Y5.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X5Y5_Click(sender As Object, e As EventArgs) Handles X5Y5.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X5Y5.BackColor = Color.Silver Then
                X5Y5.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X5Y5.BackColor = Color.Silver Then
                X5Y5.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X5Y5.BackColor = Color.Silver Then
                X5Y5.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X5Y5.BackColor = Color.Silver Then
                X5Y5.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X5Y5.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X5Y5.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X5Y5.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X5Y5.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X5Y5.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X6Y5_Click(sender As Object, e As EventArgs) Handles X6Y5.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X6Y5.BackColor = Color.Silver Then
                X6Y5.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X6Y5.BackColor = Color.Silver Then
                X6Y5.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X6Y5.BackColor = Color.Silver Then
                X6Y5.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X6Y5.BackColor = Color.Silver Then
                X6Y5.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X6Y5.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X6Y5.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X6Y5.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X6Y5.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X6Y5.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X7Y5_Click(sender As Object, e As EventArgs) Handles X7Y5.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X7Y5.BackColor = Color.Silver Then
                X7Y5.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X7Y5.BackColor = Color.Silver Then
                X7Y5.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X7Y5.BackColor = Color.Silver Then
                X7Y5.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X7Y5.BackColor = Color.Silver Then
                X7Y5.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X7Y5.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X7Y5.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X7Y5.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X7Y5.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X7Y5.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X8Y5_Click(sender As Object, e As EventArgs) Handles X8Y5.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X8Y5.BackColor = Color.Silver Then
                X8Y5.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X8Y5.BackColor = Color.Silver Then
                X8Y5.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X8Y5.BackColor = Color.Silver Then
                X8Y5.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X8Y5.BackColor = Color.Silver Then
                X8Y5.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X8Y5.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X8Y5.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X8Y5.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X8Y5.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X8Y5.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X1Y6_Click(sender As Object, e As EventArgs) Handles X1Y6.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X1Y6.BackColor = Color.Silver Then
                X1Y6.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X1Y6.BackColor = Color.Silver Then
                X1Y6.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X1Y6.BackColor = Color.Silver Then
                X1Y6.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X1Y6.BackColor = Color.Silver Then
                X1Y6.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X1Y6.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X1Y6.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X1Y6.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X1Y6.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X1Y6.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X2Y6_Click(sender As Object, e As EventArgs) Handles X2Y6.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X2Y6.BackColor = Color.Silver Then
                X2Y6.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X2Y6.BackColor = Color.Silver Then
                X2Y6.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X2Y6.BackColor = Color.Silver Then
                X2Y6.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X2Y6.BackColor = Color.Silver Then
                X2Y6.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X2Y6.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X2Y6.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X2Y6.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X2Y6.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X2Y6.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X3Y6_Click(sender As Object, e As EventArgs) Handles X3Y6.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X3Y6.BackColor = Color.Silver Then
                X3Y6.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X3Y6.BackColor = Color.Silver Then
                X3Y6.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X3Y6.BackColor = Color.Silver Then
                X3Y6.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X3Y6.BackColor = Color.Silver Then
                X3Y6.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X3Y6.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X3Y6.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X3Y6.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X3Y6.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X3Y6.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X4Y6_Click(sender As Object, e As EventArgs) Handles X4Y6.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X4Y6.BackColor = Color.Silver Then
                X4Y6.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X4Y6.BackColor = Color.Silver Then
                X4Y6.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X4Y6.BackColor = Color.Silver Then
                X4Y6.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X4Y6.BackColor = Color.Silver Then
                X4Y6.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X4Y6.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X4Y6.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X4Y6.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X4Y6.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X4Y6.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X5Y6_Click(sender As Object, e As EventArgs) Handles X5Y6.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X5Y6.BackColor = Color.Silver Then
                X5Y6.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X5Y6.BackColor = Color.Silver Then
                X5Y6.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X5Y6.BackColor = Color.Silver Then
                X5Y6.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X5Y6.BackColor = Color.Silver Then
                X5Y6.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X5Y6.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X5Y6.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X5Y6.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X5Y6.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X5Y6.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X6Y6_Click(sender As Object, e As EventArgs) Handles X6Y6.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X6Y6.BackColor = Color.Silver Then
                X6Y6.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X6Y6.BackColor = Color.Silver Then
                X6Y6.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X6Y6.BackColor = Color.Silver Then
                X6Y6.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X6Y6.BackColor = Color.Silver Then
                X6Y6.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X6Y6.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X6Y6.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X6Y6.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X6Y6.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X6Y6.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X7Y6_Click(sender As Object, e As EventArgs) Handles X7Y6.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X7Y6.BackColor = Color.Silver Then
                X7Y6.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X7Y6.BackColor = Color.Silver Then
                X7Y6.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X7Y6.BackColor = Color.Silver Then
                X7Y6.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X7Y6.BackColor = Color.Silver Then
                X7Y6.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X7Y6.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X7Y6.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X7Y6.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X7Y6.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X7Y6.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X8Y6_Click(sender As Object, e As EventArgs) Handles X8Y6.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X8Y6.BackColor = Color.Silver Then
                X8Y6.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X8Y6.BackColor = Color.Silver Then
                X8Y6.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X8Y6.BackColor = Color.Silver Then
                X8Y6.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X8Y6.BackColor = Color.Silver Then
                X8Y6.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X8Y6.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X8Y6.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X8Y6.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X8Y6.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X8Y6.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X1Y7_Click(sender As Object, e As EventArgs) Handles X1Y7.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X1Y7.BackColor = Color.Silver Then
                X1Y7.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X1Y7.BackColor = Color.Silver Then
                X1Y7.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X1Y7.BackColor = Color.Silver Then
                X1Y7.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X1Y7.BackColor = Color.Silver Then
                X1Y7.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X1Y7.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X1Y7.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X1Y7.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X1Y7.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X1Y7.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X2Y7_Click(sender As Object, e As EventArgs) Handles X2Y7.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X2Y7.BackColor = Color.Silver Then
                X2Y7.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X2Y7.BackColor = Color.Silver Then
                X2Y7.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X2Y7.BackColor = Color.Silver Then
                X2Y7.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X2Y7.BackColor = Color.Silver Then
                X2Y7.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X2Y7.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X2Y7.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X2Y7.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X2Y7.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X2Y7.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X3Y7_Click(sender As Object, e As EventArgs) Handles X3Y7.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X3Y7.BackColor = Color.Silver Then
                X3Y7.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X3Y7.BackColor = Color.Silver Then
                X3Y7.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X3Y7.BackColor = Color.Silver Then
                X3Y7.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X3Y7.BackColor = Color.Silver Then
                X3Y7.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X3Y7.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X3Y7.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X3Y7.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X3Y7.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X3Y7.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X4Y7_Click(sender As Object, e As EventArgs) Handles X4Y7.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X4Y7.BackColor = Color.Silver Then
                X4Y7.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X4Y7.BackColor = Color.Silver Then
                X4Y7.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X4Y7.BackColor = Color.Silver Then
                X4Y7.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X4Y7.BackColor = Color.Silver Then
                X4Y7.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X4Y7.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X4Y7.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X4Y7.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X4Y7.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X4Y7.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X5Y7_Click(sender As Object, e As EventArgs) Handles X5Y7.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X5Y7.BackColor = Color.Silver Then
                X5Y7.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X5Y7.BackColor = Color.Silver Then
                X5Y7.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X5Y7.BackColor = Color.Silver Then
                X5Y7.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X5Y7.BackColor = Color.Silver Then
                X5Y7.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X5Y7.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X5Y7.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X5Y7.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X5Y7.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X5Y7.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X6Y7_Click(sender As Object, e As EventArgs) Handles X6Y7.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X6Y7.BackColor = Color.Silver Then
                X6Y7.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X6Y7.BackColor = Color.Silver Then
                X6Y7.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X6Y7.BackColor = Color.Silver Then
                X6Y7.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X6Y7.BackColor = Color.Silver Then
                X6Y7.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X6Y7.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X6Y7.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X6Y7.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X6Y7.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X6Y7.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X7Y7_Click(sender As Object, e As EventArgs) Handles X7Y7.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X7Y7.BackColor = Color.Silver Then
                X7Y7.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X7Y7.BackColor = Color.Silver Then
                X7Y7.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X7Y7.BackColor = Color.Silver Then
                X7Y7.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X7Y7.BackColor = Color.Silver Then
                X7Y7.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X7Y7.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X7Y7.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X7Y7.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X7Y7.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X7Y7.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X8Y7_Click(sender As Object, e As EventArgs) Handles X8Y7.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X8Y7.BackColor = Color.Silver Then
                X8Y7.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X8Y7.BackColor = Color.Silver Then
                X8Y7.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X8Y7.BackColor = Color.Silver Then
                X8Y7.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X8Y7.BackColor = Color.Silver Then
                X8Y7.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X8Y7.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X8Y7.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X8Y7.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X8Y7.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X8Y7.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X1Y8_Click(sender As Object, e As EventArgs) Handles X1Y8.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X1Y8.BackColor = Color.Silver Then
                X1Y8.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X1Y8.BackColor = Color.Silver Then
                X1Y8.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X1Y8.BackColor = Color.Silver Then
                X1Y8.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X1Y8.BackColor = Color.Silver Then
                X1Y8.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X1Y8.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X1Y8.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X1Y8.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X1Y8.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X1Y8.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X2Y8_Click(sender As Object, e As EventArgs) Handles X2Y8.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X2Y8.BackColor = Color.Silver Then
                X2Y8.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X2Y8.BackColor = Color.Silver Then
                X2Y8.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X2Y8.BackColor = Color.Silver Then
                X2Y8.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X2Y8.BackColor = Color.Silver Then
                X2Y8.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X2Y8.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X2Y8.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X2Y8.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X2Y8.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X2Y8.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X3Y8_Click(sender As Object, e As EventArgs) Handles X3Y8.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X3Y8.BackColor = Color.Silver Then
                X3Y8.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X3Y8.BackColor = Color.Silver Then
                X3Y8.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X3Y8.BackColor = Color.Silver Then
                X3Y8.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X3Y8.BackColor = Color.Silver Then
                X3Y8.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X3Y8.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X3Y8.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X3Y8.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X3Y8.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X3Y8.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X4Y8_Click(sender As Object, e As EventArgs) Handles X4Y8.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X4Y8.BackColor = Color.Silver Then
                X4Y8.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X4Y8.BackColor = Color.Silver Then
                X4Y8.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X4Y8.BackColor = Color.Silver Then
                X4Y8.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X4Y8.BackColor = Color.Silver Then
                X4Y8.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X4Y8.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X4Y8.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X4Y8.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X4Y8.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X4Y8.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X5Y8_Click(sender As Object, e As EventArgs) Handles X5Y8.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X5Y8.BackColor = Color.Silver Then
                X5Y8.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X5Y8.BackColor = Color.Silver Then
                X5Y8.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X5Y8.BackColor = Color.Silver Then
                X5Y8.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X5Y8.BackColor = Color.Silver Then
                X5Y8.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X5Y8.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X5Y8.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X5Y8.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X5Y8.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X5Y8.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X6Y8_Click(sender As Object, e As EventArgs) Handles X6Y8.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X6Y8.BackColor = Color.Silver Then
                X6Y8.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X6Y8.BackColor = Color.Silver Then
                X6Y8.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X6Y8.BackColor = Color.Silver Then
                X6Y8.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X6Y8.BackColor = Color.Silver Then
                X6Y8.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X6Y8.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X6Y8.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X6Y8.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X6Y8.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X6Y8.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X7Y8_Click(sender As Object, e As EventArgs) Handles X7Y8.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X7Y8.BackColor = Color.Silver Then
                X7Y8.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X7Y8.BackColor = Color.Silver Then
                X7Y8.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X7Y8.BackColor = Color.Silver Then
                X7Y8.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X7Y8.BackColor = Color.Silver Then
                X7Y8.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X7Y8.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X7Y8.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X7Y8.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X7Y8.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X7Y8.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub

    Private Sub X8Y8_Click(sender As Object, e As EventArgs) Handles X8Y8.Click
        If CurrentBuilding = "GoldMine" Then
            If Gold > 49 And Energy > 0 And X8Y8.BackColor = Color.Silver Then
                X8Y8.BackColor = Color.Yellow
                Gold = Gold - 50
                Energy = Energy - 1
                Mines = Mines + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Camp" Then
            If Gold > 19 And Energy > 0 And X8Y8.BackColor = Color.Silver Then
                X8Y8.BackColor = Color.Red
                Gold = Gold - 20
                Energy = Energy - 1
                Camps = Camps + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Well" Then
            If Gold > 29 And Energy > 0 And X8Y8.BackColor = Color.Silver Then
                X8Y8.BackColor = Color.Cyan
                Gold = Gold - 30
                Energy = Energy - 1
                Wells = Wells + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Farm" Then
            If Gold > 39 And Energy > 0 And X8Y8.BackColor = Color.Silver Then
                X8Y8.BackColor = Color.Brown
                Gold = Gold - 40
                Energy = Energy - 1
                Farms = Farms + 1
            End If
            CurrentBuilding = ""
        End If

        If CurrentBuilding = "Sell" Then
            If X8Y8.BackColor = Color.Yellow Then
                Gold = Gold + 25
                Mines = Mines - 1
            End If

            If X8Y8.BackColor = Color.Red Then
                Gold = Gold + 10
                Camps = Camps - 1
            End If

            If X8Y8.BackColor = Color.Cyan Then
                Gold = Gold + 15
                Wells = Wells - 1
            End If

            If X8Y8.BackColor = Color.Brown Then
                Gold = Gold + 20
                Farms = Farms - 1
            End If

            X8Y8.BackColor = Color.Silver
            If Energy > EnergyMax - 1 Then
                Energy = EnergyMax
            End If
            CurrentBuilding = ""
        End If

        LblGold.Text = "Your Gold: " + Gold.ToString
        PgrEnergy.Value = Energy
        EnergyMax = Camps * 5 + 10
        PgrEnergy.Maximum = EnergyMax
    End Sub


    Private Sub TmrHunger_Tick(sender As Object, e As EventArgs) Handles TmrHunger.Tick
        Dim Rnd As Single = VBMath.Rnd()

        If Rnd > 0.92 Then
            Hunger = Hunger - 1
        End If
        PgrHunger.Value = Hunger
        If Hunger < 1 Then
            die()
        End If
    End Sub

    Private Sub TmrThirst_Tick(sender As Object, e As EventArgs) Handles TmrThirst.Tick
        Dim Rnd As Single = VBMath.Rnd()

        If Rnd > 0.92 Then
            Thirst = Thirst - 1
        End If
        PgrThirst.Value = Thirst
        If Thirst < 1 Then
            die()
        End If
    End Sub

    Private Sub TmrEnergy_Tick(sender As Object, e As EventArgs) Handles TmrEnergy.Tick
        If Energy < EnergyMax Then
            Energy = Energy + 1
        End If
        PgrEnergy.Value = Energy
    End Sub

    Function die()
        TmrHunger.Enabled = False
        TmrThirst.Enabled = False
        TmrEnergy.Enabled = False
        TmrResources.Enabled = False
        TmrGold.Enabled = False
        LblDie.Visible = True
        BtnRetry.Visible = True
    End Function

    Private Sub BtnRetry_Click(sender As Object, e As EventArgs) Handles BtnRetry.Click
        TmrHunger.Enabled = True
        TmrThirst.Enabled = True
        TmrEnergy.Enabled = True
        TmrResources.Enabled = True
        TmrGold.Enabled = True
        LblDie.Visible = False
        BtnRetry.Visible = False
        Gold = 420
        Water = 10
        Food = 10
        Thirst = 20
        Hunger = 20
        Energy = 10
        EnergyMax = 10
        Mines = 0
        Camps = 0
        Wells = 0
        Farms = 0
        CurrentBuilding = ""
        X1Y1.BackColor = Color.Silver
        X2Y1.BackColor = Color.Silver
        X3Y1.BackColor = Color.Silver
        X4Y1.BackColor = Color.Silver
        X5Y1.BackColor = Color.Silver
        X6Y1.BackColor = Color.Silver
        X7Y1.BackColor = Color.Silver
        X8Y1.BackColor = Color.Silver
        X1Y2.BackColor = Color.Silver
        X2Y2.BackColor = Color.Silver
        X3Y2.BackColor = Color.Silver
        X4Y2.BackColor = Color.Silver
        X5Y2.BackColor = Color.Silver
        X6Y2.BackColor = Color.Silver
        X7Y2.BackColor = Color.Silver
        X8Y2.BackColor = Color.Silver
        X1Y3.BackColor = Color.Silver
        X2Y3.BackColor = Color.Silver
        X3Y3.BackColor = Color.Silver
        X4Y3.BackColor = Color.Silver
        X5Y3.BackColor = Color.Silver
        X6Y3.BackColor = Color.Silver
        X7Y3.BackColor = Color.Silver
        X8Y3.BackColor = Color.Silver
        X1Y4.BackColor = Color.Silver
        X2Y4.BackColor = Color.Silver
        X3Y4.BackColor = Color.Silver
        X4Y4.BackColor = Color.Silver
        X5Y4.BackColor = Color.Silver
        X6Y4.BackColor = Color.Silver
        X7Y4.BackColor = Color.Silver
        X8Y4.BackColor = Color.Silver
        X1Y5.BackColor = Color.Silver
        X2Y5.BackColor = Color.Silver
        X3Y5.BackColor = Color.Silver
        X4Y5.BackColor = Color.Silver
        X5Y5.BackColor = Color.Silver
        X6Y5.BackColor = Color.Silver
        X7Y5.BackColor = Color.Silver
        X8Y5.BackColor = Color.Silver
        X1Y6.BackColor = Color.Silver
        X2Y6.BackColor = Color.Silver
        X3Y6.BackColor = Color.Silver
        X4Y6.BackColor = Color.Silver
        X5Y6.BackColor = Color.Silver
        X6Y6.BackColor = Color.Silver
        X7Y6.BackColor = Color.Silver
        X8Y6.BackColor = Color.Silver
        X1Y7.BackColor = Color.Silver
        X2Y7.BackColor = Color.Silver
        X3Y7.BackColor = Color.Silver
        X4Y7.BackColor = Color.Silver
        X5Y7.BackColor = Color.Silver
        X6Y7.BackColor = Color.Silver
        X7Y7.BackColor = Color.Silver
        X8Y7.BackColor = Color.Silver
        X1Y8.BackColor = Color.Silver
        X2Y8.BackColor = Color.Silver
        X3Y8.BackColor = Color.Silver
        X4Y8.BackColor = Color.Silver
        X5Y8.BackColor = Color.Silver
        X6Y8.BackColor = Color.Silver
        X7Y8.BackColor = Color.Silver
        X8Y8.BackColor = Color.Silver
    End Sub

    Private Sub TmrResources_Tick(sender As Object, e As EventArgs) Handles TmrResources.Tick
        Water = Water + Wells
        Food = Food + Farms
        LblWater.Text = "Your Water: " + Water.ToString
        LblFood.Text = "Your Food: " + Food.ToString
    End Sub

    Private Sub TmrGold_Tick(sender As Object, e As EventArgs) Handles TmrGold.Tick
        Gold = Gold + Mines
        LblGold.Text = "Your Gold: " + Gold.ToString
    End Sub

    Private Sub BtnDrink_Click(sender As Object, e As EventArgs) Handles BtnDrink.Click
        Thirst = Thirst + 1
        If Thirst > 20 Then
            Thirst = 20
        End If
        Water = Water - 1
        LblWater.Text = "Your Water: " + Water.ToString
        PgrThirst.Value = Thirst
    End Sub

    Private Sub BtnEat_Click(sender As Object, e As EventArgs) Handles BtnEat.Click
        Hunger = Hunger + 1
        If Hunger > 20 Then
            Hunger = 20
        End If
        Food = Food - 1
        LblFood.Text = "Your Food: " + Food.ToString
        PgrHunger.Value = Hunger
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TmrHunger.Enabled = True
        TmrThirst.Enabled = True
    End Sub
End Class
